/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.Statement;
/**
 *
 * @author HP
 */
public class Tables {
    public static void main(String args[]){
    try{
        Connection con=ConnectionProvider.getCon();
        Statement st=con.createStatement();
      //  st.executeUpdate("CREATE TABLE appuser (appuser_pk INT AUTO_INCREMENT PRIMARY KEY, userRole VARCHAR(200), name VARCHAR(200), dob VARCHAR(50), mobilenumber VARCHAR(50), email VARCHAR(50), username VARCHAR(50), password VARCHAR(50), address VARCHAR(100))");
      //  st.executeUpdate("insert into appuser(userRole,name,dob,mobilenumber,email,username,password,address) values('Admin','Admin','15-05-2002','7796292167','admin@email.com','admin','admin','india')");
      
//      String createTableQuery = "CREATE TABLE medicine (medicine_pk INT AUTO_INCREMENT PRIMARY KEY, uniqueId VARCHAR(200), name VARCHAR(200), company VARCHAR(200), quantity BIGINT, price BIGINT)";
     String createTableQuery = "CREATE TABLE BILL (bill_pk INT AUTO_INCREMENT PRIMARY KEY, billId VARCHAR(200), billDate VARCHAR(50), totalPaid BIGINT, generatedBill VARCHAR(50))";

        st.executeUpdate(createTableQuery);

    JOptionPane.showMessageDialog(null, "Table created successfully");
} catch (Exception e) {
    JOptionPane.showMessageDialog(null, e);
}
}
}



    
    
